CREATE TABLE inventory (
    id BIGINT PRIMARY KEY,
    quantity INT
);