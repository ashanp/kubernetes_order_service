INSERT INTO orders (product_id, quantity, total_price) VALUES (1, 2, 2400.00);
INSERT INTO orders (product_id, quantity, total_price) VALUES (2, 1, 800.00);
INSERT INTO orders (product_id, quantity, total_price) VALUES (3, 3, 1050.00);
INSERT INTO orders (product_id, quantity, total_price) VALUES (4, 1, 200.00);
INSERT INTO orders (product_id, quantity, total_price) VALUES (5, 2, 160.00);
INSERT INTO orders (product_id, quantity, total_price) VALUES (6, 1, 30.00);
INSERT INTO orders (product_id, quantity, total_price) VALUES (7, 1, 450.00);
INSERT INTO orders (product_id, quantity, total_price) VALUES (8, 2, 300.00);